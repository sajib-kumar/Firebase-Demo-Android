package com.example.firebasetutorial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DeleteDatActivity extends AppCompatActivity {
    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReference;
    private EditText editText;
    private ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_data);
        editText = (EditText) findViewById(R.id.id_ET_DeleteData);
        progressBar = (ProgressBar) findViewById(R.id.delete_data_data_pb_id);

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

    }

    public void clickedOnDelete(View view){
        String id = editText.getText().toString().trim();
        databaseReference = FirebaseDatabase.getInstance().getReference(firebaseUser.getUid());

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.hasChild(id)) {
                    progressBar.setVisibility(ProgressBar.VISIBLE);
                    databaseReference.child(id).removeValue();
                    progressBar.setVisibility(ProgressBar.GONE);

                    Toast.makeText(getApplicationContext(), "Deletion Successfull", Toast.LENGTH_LONG).show();


                } else {
                    Toast.makeText(getApplicationContext(), "Deletion Failed!! No match found !!", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




    }

    public void clickedOnViewData(View view) {
        Intent i = new Intent(this, ViewDataActivity.class);
        startActivity(i);
    }
}
