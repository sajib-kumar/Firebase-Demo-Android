package com.example.firebasetutorial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText emailET;
    EditText passwordET;
    Button loginBtn;
    TextView clickHereTV;

    ProgressBar progressBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("Login Activity");
        mAuth = FirebaseAuth.getInstance();

        emailET = findViewById(R.id.id_main_mail_ET);
        passwordET = findViewById(R.id.id_main_password_ET);
        loginBtn = findViewById(R.id.id_main_login_btn);
        clickHereTV = findViewById(R.id.id_main_click_here_tv);

        progressBar = findViewById(R.id.id_main_pb);

        loginBtn.setOnClickListener(this);
        clickHereTV.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.id_main_login_btn:
                userLogin();
                break;
            case R.id.id_main_click_here_tv:
                Intent intent = new Intent(this, SignUpActivity.class);
                startActivity(intent);
                break;


        }

    }

    private void userLogin() {
        final String email = emailET.getText().toString().trim();
        String password = passwordET.getText().toString();


        if (email.isEmpty()) {
            emailET.setError("Enter an email address");
            emailET.requestFocus();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailET.setError("Enter a valid email address");
            emailET.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            passwordET.setError("Enter a password");
            passwordET.requestFocus();
            return;
        }

        progressBar.setVisibility(ProgressBar.VISIBLE);

        mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressBar.setVisibility(ProgressBar.GONE);

                if(task.isSuccessful()){
                    Intent intent = new Intent(getApplicationContext(),UserDashboard.class);
                    intent.putExtra("mail",email);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }
                else{
                    Toast.makeText(getApplicationContext(),"Login Failed !! Cause: "+task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}
