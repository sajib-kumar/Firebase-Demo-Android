package com.example.firebasetutorial;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {
    EditText emailET;
    EditText passwordET;
    EditText confirm_passwordET;
    Button signupBtn;
    TextView signInTV;
    ProgressBar progressBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        this.setTitle("Sign Up Activity");
        mAuth = FirebaseAuth.getInstance();

        emailET = findViewById(R.id.id_sign_in_mail_ET);
        passwordET = findViewById(R.id.id_sign_in_password_ET);
        confirm_passwordET = findViewById(R.id.id_sign_in_confirm_password_ET);
        signupBtn = findViewById(R.id.id_sign_in_signup_btn);
        signInTV = findViewById(R.id.id_sign_in_click_here_tv);
        progressBar = findViewById(R.id.id_sign_up_pb);

        signupBtn.setOnClickListener(this);
        signInTV.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.id_sign_in_signup_btn:
                register_user();

                break;
            case R.id.id_sign_in_click_here_tv:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);

                break;
        }

    }

    private void register_user() {
        String email = emailET.getText().toString().trim();
        String password = passwordET.getText().toString();
        String conf_password = confirm_passwordET.getText().toString();

        if (email.isEmpty()) {
            emailET.setError("Enter an email address");
            emailET.requestFocus();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailET.setError("Enter a valid email address");
            emailET.requestFocus();
            return;
        }

        if (password.isEmpty() || conf_password.isEmpty()) {
            passwordET.setError("Enter a password");
            confirm_passwordET.setError("Fill Password then confirm it here");
            confirm_passwordET.requestFocus();
            return;
        }

        if (conf_password.equals(password)) {
            if (password.length() < 6) {
                passwordET.setError("Password must contain at least 5 charecter");
                passwordET.requestFocus();
                return;
            }
        } else {
            passwordET.setError("Password and Confirmation password not matched");
            passwordET.requestFocus();
            return;
        }

        progressBar.setVisibility(ProgressBar.VISIBLE);
        // If everything is okay with ui part
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                progressBar.setVisibility(ProgressBar.GONE);

                if (task.isSuccessful()) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d("MyTag", "createUserWithEmail:success");
                    Toast.makeText(getApplicationContext(), "Registration Successfull", Toast.LENGTH_LONG).show();


                } else {

                    if(task.getException() instanceof FirebaseAuthUserCollisionException)
                    {
                        Log.d("MyTag", "User is already registered.", task.getException());
                        Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                    else {
                        // If sign in fails, display a message to the user.
                        Log.d("MyTag", "createUserWithEmail:failure", task.getException());
                        Toast.makeText(getApplicationContext(), "Registration Failed. Cause: "+task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                }

            }

        });


    }
}
