package com.example.firebasetutorial;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UserDashboard extends AppCompatActivity {
    LinearLayout linearLayout;
    TextView textView;
    FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReference;
    private ProgressBar progressBar;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);

        this.setTitle("User Dashboard");

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        firebaseAuth = FirebaseAuth.getInstance();


        textView = findViewById(R.id.db_text_view_id);
        linearLayout = findViewById(R.id.db_mother_linear_layout_id);
        String mail = getIntent().getExtras().getString("mail");
        textView.setText("Welcome " + mail);
        progressBar = (ProgressBar) findViewById(R.id.dash__board_pb_id);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_layout,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.dash_board_menu_id) {
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);

        }

        return super.onOptionsItemSelected(item);
    }

    public void clickedOnAddData(View view) {
        Intent i = new Intent(this, AddDataActivity.class);
        startActivity(i);
    }

    public void clickedOnViewData(View view) {
        Intent i = new Intent(this, ViewDataActivity.class);
        startActivity(i);
    }

    public void clickedOnEditData(View view) {
        Intent i = new Intent(this, EditDataActivity.class);
        startActivity(i);

    }

    public void clickedOnDeleteData(View view) {
        Intent i = new Intent(this, DeleteDatActivity.class);
        startActivity(i);

    }

    public void clickedOnClearAll(View view) {

        databaseReference = FirebaseDatabase.getInstance().getReference(firebaseUser.getUid());
        progressBar.setVisibility(ProgressBar.VISIBLE);
        databaseReference.removeValue();
        progressBar.setVisibility(ProgressBar.GONE);
        Toast.makeText(getApplicationContext(), "All data are cleared.", Toast.LENGTH_LONG).show();


    }

}
