package com.example.firebasetutorial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class EditDataActivity extends AppCompatActivity {

    private EditText id_ET, name_ET, age_ET, gender_ET;

    private TextView textView;

    private DatabaseReference databaseReference;
    private FirebaseUser user;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_data);

        id_ET = (EditText) findViewById(R.id.id_ET_EditData);
        name_ET = (EditText) findViewById(R.id.nameET__EditData);
        age_ET = (EditText) findViewById(R.id.ageET__EditData);
        gender_ET = (EditText) findViewById(R.id.genderET__EditData);
        textView = (TextView) findViewById(R.id.tv_show_update_status);
        progressBar = (ProgressBar) findViewById(R.id.edit_data_data_pb_id) ;

        user = FirebaseAuth.getInstance().getCurrentUser();


    }

    public void clickedOnUpdate(View view) {
        Student student = new Student(id_ET.getText().toString(), name_ET.getText().toString(), age_ET.getText().toString(), gender_ET.getText().toString());
        HashMap studentHM = new HashMap();
        studentHM.put("id", student.id);
        studentHM.put("name", student.name);
        studentHM.put("age", student.age);
        studentHM.put("gender", student.gender);

        progressBar.setVisibility(ProgressBar.VISIBLE);
        databaseReference = FirebaseDatabase.getInstance().getReference(user.getUid());
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.hasChild(student.id)) {

                    databaseReference.child(student.id).updateChildren(studentHM);
                    Toast.makeText(getApplicationContext(), "Updation Successfull", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(ProgressBar.GONE);



                } else {
                    Toast.makeText(getApplicationContext(), "Updation Failed!! No match found !!", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(ProgressBar.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    public void clickedOnViewData(View view) {
        Intent i = new Intent(this, ViewDataActivity.class);
        startActivity(i);
    }
}
