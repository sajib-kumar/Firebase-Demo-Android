package com.example.firebasetutorial;

import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.ProgressBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ViewDataActivity extends AppCompatActivity {


    private TableLayout tableLayout;
    DatabaseReference databaseReference;
    private FirebaseUser user;

    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_data);
        progressBar = (ProgressBar) findViewById(R.id.id_view_data_pb);
        tableLayout = (TableLayout) findViewById(R.id.table_layout_id);

        user = FirebaseAuth.getInstance().getCurrentUser();
        // just for debug
//        checkIfLoggedIn();
        databaseReference = FirebaseDatabase.getInstance().getReference().child(user.getUid());

        loadData();

    }

    private void checkIfLoggedIn() {

        if (user != null) {
            Log.d("Mytag", "User: " + user.getEmail());
        } else {

            Log.d("Mytag", "No user");


        }
    }


    public void loadData() {


        TableRow header_row = new TableRow(getApplicationContext());
        header_row.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.table_header_shape));
        header_row.setGravity(Gravity.CENTER);

        TableRow.LayoutParams params = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f);

        ArrayList<String> arrayList = new ArrayList<>();
        ArrayList<Student> students = new ArrayList<>();
        arrayList.add("Id");
        arrayList.add("Name");
        arrayList.add("Age");
        arrayList.add("Gender");
        for (String col : arrayList) {


            TextView tv = new TextView(getApplicationContext());
            tv.setText(col.toUpperCase());
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(10, 10, 10, 10);
            tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            tv.setLayoutParams(params);
            header_row.addView(tv);


        }
        tableLayout.addView(header_row);

        progressBar.setVisibility(ProgressBar.VISIBLE);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                int count = 1;
                for (DataSnapshot studentDataSnapShot : snapshot.getChildren()) {
                    Student student = studentDataSnapShot.getValue(Student.class);
                    TableRow tr = new TableRow(getApplicationContext());
                    if (count % 2 == 0) {
                        tr.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.text_view_shape1));
                    } else {
                        tr.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.text_view_shape2));

                    }
                    count++;

                    tr.setGravity(Gravity.CENTER);

                    for (String str : arrayList) {
                        if (str.equals("Id")) {
                            str = student.id;
                        } else {
                            if (str.equals("Name")) {
                                str = student.name;

                            } else {
                                if (str.equals("Age")) {
                                    str = student.age;
                                } else {
                                    str = student.gender;
                                }
                            }
                        }


                        TextView tv = new TextView(getApplicationContext());
                        tv.setText(str);
                        tv.setGravity(Gravity.CENTER);
                        tv.setTextSize(15);
                        tv.setTextColor(getResources().getColor(R.color.colorLightWhite));
                        tv.setPadding(10, 10, 10, 10);
                        tv.setLayoutParams(params);
                        tr.addView(tv);
                    }
                    tableLayout.addView(tr);

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        progressBar.setVisibility(ProgressBar.GONE);


    }
}
