package com.example.firebasetutorial;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddDataActivity extends AppCompatActivity {

    private EditText nameET, ageET, genderET, idET;
    private ProgressBar progressBar;

    private FirebaseDatabase root;
    private DatabaseReference reference;
    private FirebaseUser user;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);


        nameET = (EditText) findViewById(R.id.nameET);
        ageET = (EditText) findViewById(R.id.ageET);
        genderET = (EditText) findViewById(R.id.genderET);
        idET = (EditText) findViewById(R.id.add_data_ET_id);
        progressBar = (ProgressBar) findViewById(R.id.add_data_pb_id);

        user = FirebaseAuth.getInstance().getCurrentUser();
        // just for debug
        checkIfLoggedIn();

        root = FirebaseDatabase.getInstance();
        reference = root.getReference().child(user.getUid());


    }

    private void checkIfLoggedIn() {

        if (user != null) {
            Log.d("Mytag", "User: " + user.getEmail());
        } else {

            Log.d("Mytag", "No user");


        }
    }


    public void clickedOnAddToDatabase(View view) {

        Student student = new Student(idET.getText().toString(), nameET.getText().toString(), ageET.getText().toString(), genderET.getText().toString());
//        Log.d("Mytag", student.name + " " + student.age);
        insertIntoStudentDB(student);
    }

    private void insertIntoStudentDB(Student student) {
        progressBar.setVisibility(ProgressBar.VISIBLE);

        try {
//            reference.push().setValue(student);  for generating random key
            reference.child(student.id).setValue(student);
            Toast.makeText(getApplicationContext(), "Data Inserted", Toast.LENGTH_LONG).show();
            idET.setText("");
            nameET.setText("");
            ageET.setText("");
            genderET.setText("");
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "Error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            Log.d("MyTag", ex.getMessage());
        }
        progressBar.setVisibility(ProgressBar.GONE);


    }

    public void clickedOnViewData(View view){
        Intent i = new Intent(this, ViewDataActivity.class);
        startActivity(i);
    }


}
